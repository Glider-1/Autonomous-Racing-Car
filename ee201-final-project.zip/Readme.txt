I have finished all the tasks in Step 1, refer to the PCB Instruction PDF through  page 1 to page 27.
Xinxu Li 2026/10/31